<?php
if(isset($_GET['var'])){
        if(';' === preg_replace('/[^\W]+\((?R)?\)/', '', $_GET['var'])) {
                if (!preg_match('/et|dir|na|info|dec|oct|pi|log/i', $_GET['var'])) {
                    eval($_GET['var']);
                }
        }
        else{
            die("Sorry!");
        }
}
else{
    show_source(__FILE__);
}
?>