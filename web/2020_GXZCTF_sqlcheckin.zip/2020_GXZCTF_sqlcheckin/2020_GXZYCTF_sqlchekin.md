---
title: 2020 GXZYCTF sqlcheckin
date: 2020-03-09 09:52:20
tags:
- Web_代码审计
- Web_sql注入
categories:
- Web
- PHP
top: 
---

![1584754809272](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_sqlcheckin\sqlcheckin\1584754809272.png)

进去可以看到这个页面, 源码如下

![1584754851134](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_sqlcheckin\sqlcheckin\1584754851134.png)

有原题

https://gksec.com/HNCTF2019-Final.html

　所以根据一番资料查找，发现`'-0-'`可以代替`'or'1`绕过。

![1584754952564](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_sqlcheckin\sqlcheckin\1584754952564.png)

