<?php
$argv[1]=$_GET['url'];
if(filter_var($argv[1],FILTER_VALIDATE_URL))
{
	$r = parse_url($argv[1]);
	print_r($r);
	if(preg_match('/happyctf\.com$/',$r['host']))
	{
		$url=file_get_contents($argv[1]);
		echo($url);
	}else
	{
		echo("error");
	}

}else
{
	echo "403 Forbidden";
}
?>