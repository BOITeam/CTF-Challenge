<?php
error_reporting(E_ALL || ~E_NOTICE);

header('content-type:text/html;charset=utf-8');
if(! isset($_GET['file']))
    header('Refresh:0;url=./index.php?file=WTNSbWFXMWhaMlV1YW5Cbg==');
$file = base64_decode(base64_decode($_GET['file']));
echo '<title>'.$_GET['file'].'</title>';
$file = preg_replace("/[^a-zA-Z0-9.]+/","", $file);
echo 'input_filename:   '. $file.'</br>';
$file = str_replace("ctf","flag", $file);
echo 'real_filename:   '.$file.'</br>';
$txt = base64_encode(file_get_contents($file));
 
echo "<img src='data:image/gif;base64,".$txt."'></img>";
/*
 * Can you find the flag file?
 *
 * Hint: hal0flagi5here.php
 */
 