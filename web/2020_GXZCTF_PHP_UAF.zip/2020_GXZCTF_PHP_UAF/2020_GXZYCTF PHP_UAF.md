`title: 2020 GXZYCTF PHP_UAF
date: 2020-03-09 09:52:20
tags:

- Web_代码审计
- UAF漏洞
  categories:
- Web
- PHP
  top: 

`





进去之后可以看到是个一句话

![1584755208667](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_PHP_UAF\PHP_UAF\1584755208667.png)

我们看一下 phpinfo





![1584755250519](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_PHP_UAF\PHP_UAF\1584755250519.png)

可以看到很先进, 是 php7.4.2, 蚁剑上去先, 由于 php 版本的问题, 我们以前的很多绕过`disable_functions`的方法都不能用

![1584755311989](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_PHP_UAF\PHP_UAF\1584755311989.png)

但是我们搜一下, 会发现有一个 uaf 洞还可以用

https://github.com/mm0r1/exploits/blob/master/php7-backtrace-bypass/exploit.php

蚁剑上传, 然后在首页包含, `cat /flag`即可

![1584755279048](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_PHP_UAF\PHP_UAF\1584755279048.png)