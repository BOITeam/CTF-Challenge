from flask import Flask, request, render_template, redirect, url_for, session, flash
from flask_bootstrap import Bootstrap
from form import RegisterForm, CmdForm
from toolkit import AESCipher
import os, requests, json, time, base64

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(32)
bootstrap = Bootstrap(app)

@app.route('/')
def index():
    return render_template('index.html', form='')

@app.route('/cmd', methods=['GET', 'POST'])
def cmd():
    form = CmdForm()
    if request.method == 'GET':
        return render_template('index.html', form=form)
    elif request.method == 'POST':
        if form.validate_on_submit():
            username = form.username.data
            master_key = form.master_key.data
            cmd = form.cmd.data
            cryptor = AESCipher(master_key)         
            authenticator = cryptor.encrypt(json.dumps({'username':username, 'timestamp': int(time.time())}))     
            res = requests.post('http://127.0.0.1:5001/getTGT', data={'username': username, 'authenticator': base64.b64encode(authenticator)})
            if res.content == 'time error':
                flash('time error')
                return redirect(url_for('index'))
            if res.content.startswith('auth'):
                flash('auth error')
                return redirect(url_for('index'))
            session['session_key'], session['TGT'] = cryptor.decrypt(base64.b64decode(res.content.split('|')[0])), res.content.split('|')[1]
            
            flash('GET TGT DONE')
           
            cryptor = AESCipher(session['session_key'])  
            authenticator = cryptor.encrypt(json.dumps({'username': username, 'timestamp': int(time.time())}))
            res = requests.post('http://127.0.0.1:5001/getTicket',  data={'username': username, 'cmd': cmd, 'authenticator': base64.b64encode(authenticator), 'TGT': session['TGT']})
            
            if res.content == 'time error':
                flash('time error')
                return redirect(url_for('index'))
            if res.content.startswith('auth'):
                flash('auth error')
                return redirect(url_for('index'))
            if res.content == 'cmd error':
                flash('cmd not allow')
                return redirect(url_for('index'))
            flash('GET Ticket DONE')
            client_message, server_message = res.content.split('|')          
            session_key = cryptor.decrypt(base64.b64decode(client_message))  
            cryptor = AESCipher(session_key)                            
            authenticator = base64.b64encode(cryptor.encrypt(username))    
            res = requests.post('http://127.0.0.1:5002/cmd', data={'server_message': server_message, 'authenticator': authenticator})

            return render_template('index.html', form='', flag=res.content)
        return render_template('index.html', form=form)
    else:
        return 'error' , 500

@app.route('/register', methods=['GET','POST'])
def register():
    form = RegisterForm()
    if request.method == 'GET':
        return render_template('index.html', form=form)
    elif request.method == 'POST':
        if form.validate_on_submit():
            username = form.username.data
            master_key = form.master_key.data
            res = requests.post('http://127.0.0.1:5001/register', data={'username': username, 'master_key': master_key})
            print res.content
            if res.content == 'duplicate username':
                return redirect(url_for('register'))
            elif res.content != '' :
                session['id'] = int(res.content)
                flash('register success')
                return redirect(url_for('index'))
        return render_template('index.html', form=form)
    else:
        return 'error' , 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, port = 5000)