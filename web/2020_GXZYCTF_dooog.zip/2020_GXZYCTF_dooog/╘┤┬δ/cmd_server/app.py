from flask import Flask, request
from toolkit import AESCipher
import os, time, base64, json, hashlib
from operator import and_

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(32)

@app.route('/cmd', methods=['POST'])
def cmd():
    server_message = request.form.get('server_message')      
    authenticator = request.form.get('authenticator')           
    cryptor = AESCipher('xxx')
    msg = cryptor.decrypt(base64.b64decode(server_message)).split('|')

    session_key = msg[0]
    cryptor = AESCipher(session_key)
    username = cryptor.decrypt(base64.b64decode(authenticator))
    print(username)
    print(msg)
    if username == msg[1]:
        os.system(msg[2])
        return 'execute success'

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, port = 5002)