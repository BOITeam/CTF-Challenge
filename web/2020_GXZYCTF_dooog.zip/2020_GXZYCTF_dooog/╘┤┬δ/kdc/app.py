from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from toolkit import AESCipher
import os, time, base64, json, hashlib
from operator import and_

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(32)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'user.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True)
    master_key = db.Column(db.String(64))

    def __repr__(self):
        return '<User %r>'  % self.username

def genSession_key():
    return hashlib.md5(os.urandom(16)).hexdigest()

@app.route('/')
def index():
    return '<h1>Dooog speaking</h1>'

@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        master_key = request.form.get('master_key')
        new_user = User(username=username, master_key=master_key)
        db.session.add(new_user)
        db.session.commit()
        return str(new_user.id)

@app.route('/check_username', methods=['POST'])
def check_username():
    return '1' if User.query.filter_by(username=request.form.get('username')).first() != None else '0'

@app.route('/getTGT', methods=['POST'])
def TGT_vender():
    username = request.form.get('username')
    authenticator = request.form.get('authenticator')
    user = User.query.filter_by(username=username).first()
    if user != None:
        cryptor = AESCipher(user.master_key)
        try:
            data = json.loads(cryptor.decrypt(base64.b64decode(authenticator)))
            if data['username'] == username:
                if int(time.time()) - data['timestamp'] < 60:                  
                    session_key = genSession_key()
                    session_key_enc = base64.b64encode(cryptor.encrypt(session_key))   
                    cryptor = AESCipher(app.config.get('SECRET_KEY'))
                    TGT = base64.b64encode(cryptor.encrypt(username + '|' + session_key + '|' + str(int(time.time()))))             
                    return session_key_enc + '|' + TGT
        except Exception:
            return 'auth fail'
    return "auth error"

@app.route('/getTicket', methods=['POST'])
def Ticket_vender():
    username = request.form.get('username')     
    authenticator = request.form.get('authenticator')      
    TGT = request.form.get('TGT')                           
    cmd = request.form.get('cmd')       
    user = User.query.filter_by(username=username).first()
    if user != None:
        cryptor = AESCipher(app.config.get('SECRET_KEY'))
        auth_data = cryptor.decrypt(base64.b64decode(TGT)).split('|')
        cryptor = AESCipher(auth_data[1])     
        try:
            data = json.loads(cryptor.decrypt(base64.b64decode(authenticator)))
            if data['username'] == auth_data[0] == username:
                if int(time.time()) - data['timestamp'] < 60:       
                    if cmd not in ['whoami', 'ls']:       
                        return 'cmd error'
                session_key = genSession_key()     
                session_key_enc = base64.b64encode(cryptor.encrypt(session_key))     
                cryptor = AESCipher(auth_data[1])  
                client_message = base64.b64encode(cryptor.encrypt(session_key))         
                server = User.query.filter_by(username='cmd_server').first()
                cryptor = AESCipher(server.master_key)                
                server_message = base64.b64encode(cryptor.encrypt(session_key + '|' + data['username'] + '|' + cmd))  
                return client_message + '|' + server_message      
        except Exception:
            return ' fail'
    return "auth error"

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, port = 5001)