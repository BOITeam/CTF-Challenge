---
title: 2020 GXZYCTF webct
date: 2020-03-09 09:52:20
tags:
- mysql服务端伪造
- phar反序列化
categories:
- Web
- PHP
top: 
---

部分源码

```php
<?php
error_reporting(0);
class Db
{
    public $ip;
    public $user;
    public $password;
    public $option;
    function __construct($ip,$user,$password,$option)
    {
        $this->user=$user;
        $this->ip=$ip;
        $this->password=$password;
        $this->option=$option;
    }
    function testquery()
    {
        $m = new mysqli($this->ip,$this->user,$this->password);
        if($m->connect_error){
            die($m->connect_error);
        }
        $m->options($this->option,1);
        $result=$m->query('select 1;');
        if($result->num_rows>0)
        {
            echo '测试完毕，数据库服务器处于开启状态';
        }
        else{
            echo '测试完毕,数据库服务器未开启';
        }
    }
}

class File
{
    public $uploadfile;
    function __construct($filename)
    {
        $this->uploadfile=$filename;
    }
    function xs()
    {
        echo '请求结束';
    }
}

class Fileupload
{
    public $file;
    function __construct($file)
    {
        $this->file = $file;
    }
    function deal()
    {
        $extensionarr=array("gif","jpeg","jpg","png");
        $extension = pathinfo($this->file->uploadfile['name'], PATHINFO_EXTENSION);
        $type = $this->file->uploadfile['type'];
        //echo "type: ".$type;
        $filetypearr=array("image/jpeg","image/png","image/gif");
        if(in_array($extension,$extensionarr)&in_array($type,$filetypearr)&$this->file->uploadfile["size"]<204800)
        {
            if ($_FILES["file"]["error"] > 0) {
                echo "错误：: " .$this->file->uploadfile["error"] . "<br>";
                die();
            }else{
                if(!is_dir("./uploads/".md5($_SERVER['REMOTE_ADDR'])."/")){
                    mkdir("./uploads/".md5($_SERVER['REMOTE_ADDR'])."/");
                }
                $upload_dir="./uploads/".md5($_SERVER['REMOTE_ADDR'])."/";
                move_uploaded_file($this->file->uploadfile["tmp_name"],$upload_dir.md5($this->file->uploadfile['name']).".".$extension);
                echo "上传成功"."<br>";
            }
        }
        else{
            echo "不被允许的文件类型"."<br>";
        }
    }
    function __destruct()
    {
        $this->file->xs();
    }
}
class Listfile
{
    public $file;
    function __construct($file)
    {
        $this->file=$file;
    }
    function listdir(){
        system("ls ".$this->file)."<br>";
    }
    function __call($name, $arguments)
    {
        system("ls ".$this->file);
    }
}
```

首先题目分为两个功能，一个是连接数据库，一个是上传文件

这儿的解题思路为

上传`phar.gif`，利用mysql服务端恶意读取文件触发`phar://`

记录一个小坑，PHP的配置一般是常量，因此可以打印下从而解决直接传`MYSQLI_OPT_LOCAL_INFILE`传输后变字符串的问题

```php
<?php
    $m = new mysqli('117.78.1.xxx','root','root');
    if($m->connect_error){
        die($m->connect_error);
    }
    var_dump(MYSQLI_OPT_LOCAL_INFILE);
    $m->options(MYSQLI_OPT_LOCAL_INFILE,1);
    $result=$m->query('select 1;');
```

打印出来的值为8，即option为8

这样就能知道常量MYSQLI_OPT_LOCAL_INFILE的值为多少了~~

我们直接在vps上开一个mysql服务端，然后读取的文件为phar://xxxx

这儿的文件为我们上传的phar文件，这样就能触发phar://反序列化了~~