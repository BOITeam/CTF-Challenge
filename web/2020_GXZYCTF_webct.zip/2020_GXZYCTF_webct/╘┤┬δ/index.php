<?php
error_reporting(0);
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Some Useful Tools</title>
</head>
<body>
<a href="./testsql.html">测试mysql服务器</a>
<a href="./filestore.html">图片云存储</a>
</body>
</html>